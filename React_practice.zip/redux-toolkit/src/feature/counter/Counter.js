import React, { useState } from 'react'
import {useSelector,useDispatch} from 'react-redux';
import {increment,decrement,incrementByAmount} from './counterSlice'
function Counter() {
    const [input,setInput] = useState(0);
    const count = useSelector((state)=>state.counter.count)
    const dispatch = useDispatch(); 
    const onChnage=(e)=>{
         setInput(Number(e.target.value))
    }
    return (
    <div>
    <button onClick={()=>{dispatch(increment())}}>+</button>
    {count}
    <button onClick={()=>{dispatch(decrement())}}>-</button>
    <div>
      <input type='number' onChange={onChnage} value={input} />
    <button onClick={()=>{dispatch(incrementByAmount(input))}}>Inc By Amount</button>
    </div>
    
    </div>
  )
}

export default Counter;