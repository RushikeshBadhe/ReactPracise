import { createSlice } from "@reduxjs/toolkit";
import { users } from "../../data/Data";
export const userSlice = createSlice({
    name:'users',
    initialState:{value:users},
    reducers:{
        addUser:(state,action)=>{
            state.value.push(action.payload)
        }
    }
})

export const {addUser} = userSlice.actions;
export default userSlice.reducer;