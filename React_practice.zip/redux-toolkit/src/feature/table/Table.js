import React,{useState} from 'react';
import { users } from '../../data/Data';
import {useSelector,useDispatch} from 'react-redux';
import { addUser } from './tableSlice';
function Table() {
    const [name,setName] = useState('');
    const [id,seId] = useState('');
    const [mail,setMail] = useState('');
    const dispatch = useDispatch();
    const userList = useSelector((state)=>{
        return state.users.value
    });
    console.log(userList);
  return (  
    <div>
        <h3>Table</h3>
        <input type="number" placeholder='id' value={id} 
        onChange={((e)=>seId(e.target.value))}/>
        <input type="text" placeholder='name' value={name} 
        onChange={((e)=>setName(e.target.value))}/>
        <input type="text" placeholder='mail' value={mail}
        onChange={((e)=>setMail(e.target.value))} /><br/>
        <button onClick={()=>{
            dispatch(addUser({id,name,mail}))
        }}>Submit</button>
     {users.map((u,index)=>{
         return(
            <p key={index}>{u.name}</p>
         )
     })}
    </div>
  )
}
export default Table;