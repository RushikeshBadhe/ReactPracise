
import './App.css';
import Counter from './feature/counter/Counter';
import Table from './feature/table/Table';

function App() {
  return (
    <div className="App">
      <h3>Redux Toolkit</h3>
      <Counter/>
      <Table/>
    </div>
  );
}

export default App;
