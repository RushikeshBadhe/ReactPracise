export const users = [
    {id:1,name:'user1',mail:'user1@gm.com'},
    {id:2,name:'user2',mail:'user2@gm.com'}
]