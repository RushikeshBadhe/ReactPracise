import {configureStore} from '@reduxjs/toolkit';
import cartReducer from './cartSlice'
import productReducer from './productsSlice'
import searchReducer from './searchSlice';
const store = configureStore({
    reducer:{
        cart:cartReducer,
        product:productReducer,
        search:searchReducer
    }
})

export default store;