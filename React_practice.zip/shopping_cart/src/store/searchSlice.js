const {createSlice} = require("@reduxjs/toolkit");
const initialState = ['Rushi','Shubham','Snehal'];

const searchSlice = createSlice({
    name:'search',
    initialState,
    reducers:{
        search(state,action){
            return state = state.filter(item=>item.title===action.payload)
        }
    }
});

export const {search} = searchSlice.actions;
export default searchSlice.reducer;
