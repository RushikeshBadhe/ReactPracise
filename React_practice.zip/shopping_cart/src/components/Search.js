
import { useSelector } from "react-redux";
const Search=()=>{
   const data = useSelector(state=>state.search);
   console.log(data);
    return(
        <div>
            Search
        </div>

    )
}

export default Search;