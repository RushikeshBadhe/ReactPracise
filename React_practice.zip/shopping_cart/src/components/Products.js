import React,{useState,useEffect} from 'react'
import './products.css'
import { add } from '../store/cartSlice';
import {useDispatch,useSelector} from 'react-redux'
import { fetchProducts } from '../store/productsSlice';
import { STATUSES } from '../store/productsSlice';
function Products() {
    // const [products,setProducts]  = useState([]);
    const dispatch = useDispatch();
    const {data:products,status} = useSelector((state)=>state.product);
    useEffect(() => {
      dispatch(fetchProducts())
      //  const fetchProduct=async()=>{
      //       const res = await fetch('https://fakestoreapi.com/products');
      //       const data = await res.json();
      //       setProducts(data);
            
      //  }
      //  fetchProduct()
        
    }, []);
    console.log(products);
    const handleAdd =(product)=>{
       dispatch(add(product))
    }
    if(status === STATUSES.LOADING){
      return(
        <h2>Loading.....</h2>
      )
    }
  return (

    <div className='productsWrapper'>
        {
            products.map(p=>(
                <div className='card' key={p.id}>
                <img className='images' src={p.image} alt="" />
                <h4>{p.title}</h4>
                <h4>{p.price}</h4>
                <button className='btn' onClick={()=>handleAdd(p)} >Add to cart</button>
              </div>
            ))
                
        }
    </div>
  )
}

export default Products