import {useRef, useState}  from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
import { search } from '../store/searchSlice';
import './navbar.css'

function Navbar() {
  const items = useSelector((state)=>state.cart);
   const dispatch = useDispatch();
  const input = useRef()
  const srch =(s)=>{
     
    dispatch(search(s))
  }
  return (
    <div>
        <nav className='navbar' >
        <span className='logo' >REDUX STORE</span>
        <input type="checkbox" id='toggler'/>
        <label htmlFor='toggler'><i className='ri-menu-line'></i></label>
        <div className='menu' >
         <ul className='list' >
            <li><Link className='navLink' to='/'>Home</Link></li>
            <li><Link className='navLink' to='/cart'>Cart</Link></li>
            <li> <span className='cartCount' >
                Cart items: {items.length}
            </span></li>
         </ul>
         
        </div>
        <input className='srch' type="text" placeholder="Search.." ref={input}></input>
        <button onClick={srch(input.current)}>Search</button>
        </nav>
    </div>
  )
}

export default Navbar