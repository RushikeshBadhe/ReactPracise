
import './App.css';
import {BrowserRouter, Route, Routes} from 'react-router-dom'
import Home from './pages/Home';
import Cart from './pages/Cart';
import Navbar from './components/Navbar';
import {Provider} from 'react-redux';
import store from './store/store';
import Search from './components/Search';
function App() {
  return (
    <div className="App">
      <h2>React Shopping Cart</h2>
        <Provider store={store}>
        <BrowserRouter>
      <Navbar/>
      
        <Routes>
          <Route path='/' element={<Home/>} ></Route>
          <Route path='/cart' element={<Cart/>} ></Route>
          <Route path='search' element={<Search/>}></Route>
        </Routes>
      </BrowserRouter>
        </Provider>
    </div>
  );
}

export default App;
