import React ,{useState}from 'react';
import Form from 'react-bootstrap/Form'
import {Row,Col,Button} from 'react-bootstrap'
import axios from 'axios'

function Department() {
    const[input,setInput] = useState({dname:'',daddress:'',dcode:''});

  const formSubmit=(e)=>{
    e.preventDefault();
    axios.post('https://reqres.in/api/articles', input)
    .then(response => {
      alert('Submitted');
      console.log(response)
    }
    ).catch(err=>{alert(err)})
    console.log(input);
  }
  const handleChange=(evt)=>{
    const setName = evt.target.name;
    const value = evt.target.value;
    setInput({...input,[setName]:value})
   // console.log(input);
  }
  return (
    <div className="d-flex justify-content-center">
     
  <Form className='w-50 p-' onSubmit={formSubmit}>
  <h3>Department</h3>
  <Row className="mb-3">
    <Form.Group as={Col} controlId="formGridEmail">
      <Form.Label>Department Name</Form.Label>
      <Form.Control type="text" name='dname' onChange={handleChange} value={input.dname} placeholder="Enter Department Name" />
    </Form.Group>
   
  </Row>
  <Form.Group className="mb-3" controlId="formGridAddress1">
    <Form.Label>Address</Form.Label>
    <Form.Control type='text' name='daddress' onChange={handleChange}  value={input.dadderss} placeholder="Enter Address" />
  </Form.Group>
    <Form.Group className='mb-3' as={Col} controlId="formGridZip">
      <Form.Label>Department Id</Form.Label>
      <Form.Control type='number' onChange={handleChange}  value={input.dcode} name='dcode' placeholder='department code' />
    </Form.Group>
  <Button variant="primary" type="submit">
    Submit
  </Button>
  </Form>
 
    </div>
  )
}

export default Department