import axios from 'axios';
import React, {useEffect, useState } from 'react'
import '../App.css'
function Search() {
    const[id,setId] = useState();
    const[details,setDetails] = useState();
    const[newId,setNewId] = useState();
    const[date,newDate] = useState();
    let getId=(e)=>{
       setId(e.target.value);
    }
  useEffect(()=>{
      
      try {
        setNewId(details.id)
        newDate(details.createdAt)
      } catch (error) {
          console.log(error);
      }
    
  },[details])

    let sendId=()=>{
        if(id===''){
            alert('Fill id')
        }else{
            axios.post('https://reqres.in/api/articles',id
            ).then((res)=>{
                console.log(res);
                setDetails(res.data);
                
               
                //console.log(newId);
            }).catch((err)=>alert(err))
            //console.log(id);
        }  
    }
    return (
        <div >
            <h3 className='d-flex justify-content-center' >Search</h3>
            <div className='d-flex justify-content-center'>
            
            <div className="input-group w-25 p-3 ">
                <input type="number" className="form-control rounded" onChange={getId} placeholder="User ID" aria-label="Search" aria-describedby="search-addon" />
                <button type="button" className="btn btn-outline-primary" onClick={sendId}>search</button>
            </div>
            </div>
            <div className='d-flex-column align-content-center'>
              
            <p>
            id: {newId}
            </p><br/>
           date:{date}
            </div>
            
         
           
            
              
        </div>
    )
}

export default Search