import React, { useState } from 'react'
import Form from 'react-bootstrap/Form'
import {Row,Col,Button} from 'react-bootstrap'
import axios from 'axios'
import '../App.css'
function Details() {
  const[input,setInput] = useState({fname:'',lname:'',email:'',deptid:''});

  const formSubmit=(e)=>{
    e.preventDefault();
    axios.post('https://reqres.in/api/articles', input)
    .then(response => {
      alert('Submitted');
      console.log(response)
    }
    ).catch(err=>{alert(err)})
    console.log(input);
  }
  const handleChange=(evt)=>{
    const setName = evt.target.name;
    const value = evt.target.value;
    setInput({...input,[setName]:value})
   // console.log(input);
  }
  return (
    <div className="d-flex justify-content-center">
     
  <Form className='w-50 p-' onSubmit={formSubmit}>
  <h3>User Details</h3>
  <Row className="mb-3">
    <Form.Group as={Col} controlId="formGridEmail">
      <Form.Label>First Name</Form.Label>
      <Form.Control type="text" name='fname' onChange={handleChange} value={input.fname} placeholder="Enter first name" />
    </Form.Group>
    <Form.Group as={Col} controlId="formGridPassword">
      <Form.Label>Last Name</Form.Label>
      <Form.Control type="text" name='lname' onChange={handleChange}  value={input.lname} placeholder="Enter last name" />
    </Form.Group>
  </Row>
  <Form.Group className="mb-3" controlId="formGridAddress1">
    <Form.Label>Email</Form.Label>
    <Form.Control type='email' name='email' onChange={handleChange}  value={input.email} placeholder="enter email" />
  </Form.Group>
    <Form.Group className='mb-3' as={Col} controlId="formGridZip">
      <Form.Label>Department Id</Form.Label>
      <Form.Control type='number' onChange={handleChange}  value={input.deptid} name='deptid' placeholder='department id' />
    </Form.Group>
  <Button variant="primary" type="submit">
    Submit
  </Button>
  </Form>
 
    </div>
  )
}

export default Details;