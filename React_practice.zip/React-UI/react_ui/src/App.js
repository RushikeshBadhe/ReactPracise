
import './App.css';
import Details from './components/Details';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Department from './components/Department';
import Search from './components/Search';
function App() {
  return (
    <div>

      <Router>
        <div>
          <nav className="navbar navbar-dark bg-primary">
            <div className="container-fluid justify-content-center jsu">
              <Link className="navbar-brand" to={'/'}>AddUser</Link>
              <Link className="navbar-brand" to={'department'}>Department</Link>
              <Link className="navbar-brand" to={'search'}>Search</Link>
            </div>
          </nav>
        </div>
        <Routes>
          <Route path='/' element={<Details />} />
          <Route path='department' element={<Department />} />
          <Route path='search' element={<Search />} />
          <Route path='*' element={<Details />} />
        </Routes>
      </Router>
    </div>

  );
}

export default App;
