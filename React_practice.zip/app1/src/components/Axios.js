import  { useEffect,useState } from 'react';
import React from "react";
import axios from 'axios'
function Axios(){
    const [users,setUsers] = useState()
    const url = 'https://reqres.in/api/users';

    useEffect(()=>{
        // console.log("useEffect");
        axios.get('https://reqres.in/api/users').then((response)=>{
        //    var info = response.data.data;
           setUsers(response.data.data)
        //    console.log(users);
           
        //    console.log(info);
        })
     
     
    },[])
    console.log(users);
    
    // setUsers('yes')
    return(
        <>
         
        </>
    )
}

export default Axios;