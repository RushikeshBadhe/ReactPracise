import { useState } from "react";
import {Button} from 'react-bootstrap'
export function UseState(){
    const[Lname,setLname] = useState("??")

   let handleClick=()=>{
        setLname('Badhe')
    }
    return(
        <>
       <h3>My sir name is {Lname}</h3>
       <Button onClick={handleClick} variant="outline-primary">Reveal</Button>

       </>
    )
}