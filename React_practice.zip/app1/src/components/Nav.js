import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'
import { UseState } from './UseState'
function Nav(){
    return(
        <>
        
            <Route path='/usestate' component={UseState}/>
       
        </>
    )
}

export default Nav;