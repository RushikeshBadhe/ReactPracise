import React, { useState,useEffect } from "react";

function Useeffects(props) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [allEm,setAllEm] = useState([]);
  
  //when every time component is updated
  useEffect(()=>{
    console.log('Use effect working');
  })
  
  //only on first render - componentDidMount alternative
  useEffect(()=>{
    console.log('Use effect working on 1st render');
  },[])
  
  //on 1st render + when dependancy changes similiar to componentDidUpdate
  useEffect(()=>{
    console.log('Use effect working for update name');
  },[name])

  //perform cleanup similar to componentWillUnmount
  useEffect(()=>{
    
    return()=>{
      console.log("I am unmounted");
    }
  },[name])
  
  
  const handleSubmit = (evt) => {
    evt.preventDefault();
   
    const Entry = {email:email,name:name}

    setAllEm([Entry])
    
    console.log(allEm);
    // setEmail(email);
    // setName(name);
  }

    const handleOnChange1 = (event) => {
    console.log("On change");

    setName(event.target.value)
    // console.log(`Name :${name}`)
    // console.log(`Email :${email} `);

  }

  const handleOnChange2 = (event) => {
    console.log("On change");

    setEmail(event.target.value)

  }

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>
          Enter Name:
          <input
            type="text"
            value={name}
            onChange={handleOnChange1}
          />
        </label>
        <label>
          Enter Email
          <input type="email"
            value={email}
            onChange={handleOnChange2}
          />
        </label>
        {/* <input type="submit" value="Submit" /> */}
        <button onClick={handleSubmit}>Submit</button>
      </form>
      <div>
           {
             allEm.map((data=>{
               return(
                 <div>
               <p>Name :{data.name}</p>
               <p>Email :{data.email}</p>
               </div>
               )
             }))
           }
      </div>
    </div>
  );
}
export default Useeffects;