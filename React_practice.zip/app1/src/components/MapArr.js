import React from 'react'
function Map() {
    let arr = [{ name: "Rajat", Id: 101 },
    { name: "Joggy", Id: 102 },
    { name: "Rambo", Id: 103 }
    ]

    return (
        <div>
            <table border='2'>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                </tr>
                {arr.map(info => {
                    return (
                        <tr>
                            <td>
                                {info.Id}
                            </td>
                            <td>
                                {info.name}
                            </td></tr>
                    )
                })}
            </table>
        </div>
    )


}

export default Map;