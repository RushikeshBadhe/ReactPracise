import { Link } from "react-router-dom";

export function Props(props){
    return(
        <>
        <h3>I am {props.name}</h3>
        <Link to='/usestate'>L Name</Link>
        </>
    )
}