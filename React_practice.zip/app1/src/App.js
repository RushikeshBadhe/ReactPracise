
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'
import './App.css';
//import Axios from './components/Axios';
//import Form from './components/Form';
import Login from './components/Login';
import Nav from './components/Nav';
// import Map from './components/MapArr';
import { Props } from './components/Props';
import Useeffects from './components/Useeffects';

import { UseState } from './components/UseState';
function App() {
  return (
   
    <div>
      <Router>
      <Useeffects/>
     {/* <Axios></Axios> */}
      
      <Props name="Rushikesh"></Props>
      <Nav></Nav> */}
    {/* <Login/> */}
      </Router>
    </div>
    
  );
}

export default App;
