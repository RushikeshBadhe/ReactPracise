import { ITask } from "../interfaces";

interface Props {
    task: ITask;
}
const TodoTask = ({ task }: Props) => {

    return (
        <>
            <div>
                {task.taskName}
                {task.deadLine}
            </div>
        </>
    )
}

export default TodoTask;