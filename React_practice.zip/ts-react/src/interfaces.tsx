export interface ITask{
   taskName:string;
   deadLine:number;
}