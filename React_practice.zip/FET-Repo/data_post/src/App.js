
import './App.css';
import Form from './components/Form';
import { BrowserRouter, Link,Routes,Route } from "react-router-dom";
import Info from './components/Info';
function App() {
  return (
    <BrowserRouter>
   
    <div>
      <Form/>
      <Routes>
    
      <Route path="info" element={<Info/>} />
    </Routes>
    </div>
    </BrowserRouter>
  );
}

export default App;
