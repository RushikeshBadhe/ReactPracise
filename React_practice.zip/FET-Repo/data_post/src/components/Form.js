import React,{useState} from 'react';
import './style.css';
import Axios from 'axios';
import { Link } from 'react-router-dom';

function Form() {
    const [data, setData] = useState({BookId:'',BookName:'',BookAuthor:''});

    const formData=(e)=>{
      const name = e.target.name;
      const val = e.target.value;
      setData({...data,[name]:val});
   
    }
    const submitData=(event)=>{
      event.preventDefault()
      Axios.post('https://reqres.in/api/users',data)
      .then((res)=>{
        if (res.status===201) {
          alert('data Successfully Posted')
        }
      })
      .catch((err)=>alert(err))
       console.log(data);
    }
  return (
    <div>
    <div className="testbox">
    <form onSubmit={submitData}>
      <div className="banner">
        <h1>Form Data Submission</h1>
      </div>
      <div className="colums">
        <div className="item">
          <label htmlFor="fname">Book Id<span>*</span></label>
          <input id="fname" type="text" name="BookId" onChange={formData} required/>
        </div>
        <div className="item">
          <label htmlFor="lname"> Book Name<span>*</span></label>
          <input id="lname" type="text" name="BookName" onChange={formData}  required/>
        </div>
      
        <div className="item">
          <label htmlFor="zip">Book Author<span>*</span></label>
          <input id="zip" type="text" name="BookAuthor" onChange={formData}  required/>
        </div>
      </div>    
    
      <div className="btn-block">
        <button type='submit'>Submit</button>
      </div>
     
      </form>  
      
  </div>
   {/* //Table */}
   <div className="btn-block">
        <Link className="btn" to={'/info'}>Get data</Link>
      </div>
   
  </div>
  )
}

export default Form