import React,{useEffect,useState} from 'react'
import Axios from 'axios';
function Info() {
    const [info, setInfo] = useState([]);
    useEffect(() => {
        Axios.get('https://reqres.in/api/users?page=2').then((res) => {
            setInfo(res.data.data)
        })
       
    }, []);

  return (
    <div>
        <h2>Table</h2>
            <table>
                <thead>
                <tr>
                    <th>BookId</th>
                    <th>BookName</th>
                    <th>BookAuthor</th>
                   
                </tr>
                </thead>
               <tbody>
                   {
                       info.map((info,index)=>{
                           return(
                            <tr key={index}>
                            <td>{info.id}</td>
                            <td>{info.first_name}</td>
                            <td>{info.last_name}</td>
                            
                        </tr>
                           )
                       })
                   }
               </tbody>
            </table>

    </div>
  )
}

export default Info