import React,{useState,useMemo} from 'react'

function UseMemo() {
    const [state, setstate] = useState(0);
    const [numbere,setNumber] = useState(0);
    const square = useMemo(()=>{
       return squareNumber(numbere);

    },[numbere])
    const Inc=()=>{
      setstate(state+1);
    }
   function squareNumber(numbere){
       console.log('square Function running');
       return Math.pow(numbere,2);
   }
   
  return (
    <div> 
        <hr/>
        <h3>useMemo</h3>
        <div><h3>increment Number</h3></div>
        <p>{state}</p>
        <button onClick={Inc}>increment</button>
        <div><h3>square of Number</h3></div>
        <input onChange={(e)=>setNumber(e.target.value)} type="number" />
        <p>{square}</p>
    </div>
  )
 

}

export default UseMemo