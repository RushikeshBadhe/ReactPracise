import React, { useState } from 'react';
import '../App.css'
function States() {
    let [num,newNum] = useState(0)
    
    let incNum =()=>{
     num = parseInt(num)
      console.log('type of '+typeof(num));
      newNum(num+1)
    }
  let decNum=()=>{
    newNum(num-1)
  }
  console.log(typeof(num));
  return (
    <>
      <h3>State</h3>
      <input type={'number'} value={num}  onChange={e=>newNum(e.target.value)}></input>
      <button onClick={incNum}>+</button>
      <button onClick={decNum}>-</button>
      <hr/>
    </>
  )
 
}

export default States;
