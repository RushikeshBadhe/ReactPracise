import React, { useLayoutEffect, useState } from 'react';

function UseLayoutEffect() {
    const [colour,setColour] = useState('white')
    useLayoutEffect(()=>{
        setColour('Red')
        console.log('usesLayouteffect');
    },[])
    
  return (
  <div style={{'backgroundColor':colour}}>
     <h3>useLayoutEffect</h3>
     Background color<br/>
     useLayoutEffect hook is invoked synchronously before changes are painted on the screen.
     It runs before useEffect.Mainly we use it to handle Styling changes in UI
     <hr/>
  </div>
  )
}

export default UseLayoutEffect;
