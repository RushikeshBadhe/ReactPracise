import React, { useEffect, useState } from 'react';

function UseEffects() {
    let [state,setState]=useState()

  useEffect(()=>{

      setState('Loaded as soon as page rendered')
      console.log('useEffects');

  },[])
  
  return(
   <div>
    <h3>useEffects</h3>
    <p>{state}</p>
    <hr/>
  </div>
 )
}

export default UseEffects;
