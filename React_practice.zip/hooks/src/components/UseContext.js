import React, { useContext } from 'react';
import CompAContext from '../context/compA/CompAContext';
//import CompA from '../context/compA/CompA';
const UseContext = () => {
    const me = useContext(CompAContext)
  return (
  <div>
   <h3>useContext</h3>
    Getting name {me} from useContext CompAstate
  </div>)
};

export default UseContext;
