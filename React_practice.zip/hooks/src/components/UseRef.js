import React, { useRef, useState } from 'react';
export const UseRef = () => {
    let [val,newVal] = useState()
    let inputRef = useRef()
    console.log(inputRef);
    const changeWidth=()=>{
      inputRef.current.style.width="400px";
      console.log(inputRef.current);
      console.log('Hey');
    }
  return(
   <div>
     <h3>useRef</h3>
     <input style={{width:'100px'}} ref={inputRef}/>
     <button onClick={()=>{inputRef.current.focus()}}>Focus</button>
     <button onClick={()=>{
         newVal(inputRef.current.value)
         console.log(inputRef.current )}}>Value</button>

         <button onClick={changeWidth}>Change Width</button>
     <br/>
     <p>{val}</p>
     <hr/>
  </div>
  )
};
