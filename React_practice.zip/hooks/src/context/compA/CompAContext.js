import {createContext} from "react";

const CompAContext = createContext()

export default CompAContext;