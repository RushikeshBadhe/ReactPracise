import UseContext from "../../components/UseContext";
import CompAContext from "./CompAContext";

const CompA=(props)=>{
    const state = ['name1','name2']
  return(
    <CompAContext.Provider value={state}>
        {props.children}
        {/* <UseContext/> */}
    </CompAContext.Provider>
  )
}

export default CompA;