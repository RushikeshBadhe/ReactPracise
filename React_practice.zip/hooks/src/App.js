import './App.css';
import States from './components/States';
import UseContext from './components/UseContext';
import UseEffects from './components/UseEffects';
import UseLayoutEffect from './components/UseLayoutEffect';
import UseMemo from './components/UseMemo';
import { UseRef } from './components/UseRef';
import CompA from './context/compA/CompA';

function App() {
  return (
    <div >

     <CompA>
     <States/>
     <UseEffects/>
     <UseRef/>
     <UseLayoutEffect/>
     <UseContext/>
     </CompA>
     <UseMemo/>
     
    </div>
  );
}

export default App;
