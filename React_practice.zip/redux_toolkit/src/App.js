
import { useState } from 'react';
import { useSelector,useDispatch} from 'react-redux';
import './App.css';
import {addUser} from './features/Users';

function App() {
  const [name,setName] = useState('');
  const dispatch = useDispatch();
  const [userName,setUserName] = useState('');
  const userList = useSelector((state)=>{
    return state.users.value
  })
  return (
    <div className="App" >
     <h2>React Redux</h2>

     <div className='addUser'>
       <input type='text' placeholder='Name..' value={name} onChange={(e)=>{
         setName(e.target.value)
       }}/>
       <input type='text' placeholder='UserName..'  onChange={(e)=>setUserName(e.target.value)} />
      <button onClick={()=>{
        dispatch(addUser({id:0,name:name,userName:userName}))

      }} >Add User</button>
     </div>
     <div className='users'>
     <table className='displayusers' >
       
     <thead className='thead' >
           <td >Name</td>
           <td >UserName</td>
         </thead>
        
      {userList.map((user)=>{
        return (
        <tr  >
          <td >
          {user.name}
          </td>
          <td>
            {user.userName}
          </td>
          </tr>
        )
      })}
      </table>
     </div>

    </div>
  );
}

export default App;
