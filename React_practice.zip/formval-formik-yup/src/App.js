
import './App.css';
import Forms from './components/Form';
import Form2 from './components/Form2';

function App() {
  return (
    <div >
    {/* <Forms/> */}
    <Form2/>
    
    </div>
  );
}

export default App;
