import React from 'react'
import img from './pngtree.jpg'
import { Formik, Form, Field, ErrorMessage } from "formik";
import { userSchema } from "./Validation";
function Form2() {
    const initialValues = {
        email: "",
        password: "",
        name: "",
        confirmPassword: "",
        checkbox: "",
    };
    const submitForm = (values) => {
        console.log(values);
        
    };
    return (
        <Formik
            initialValues={initialValues}
            validationSchema={userSchema}
            onSubmit={submitForm}
        >
            {(formik) => {
                const { errors, touched, isValid, dirty } = formik;
                return (
                    <div className='div1'>
                        <section className="vh-200 sec1" >
                            <div className="container h-100">
                                <div className="row d-flex justify-content-center align-items-center h-100">
                                    <div className="col-lg-12 col-xl-11">
                                        <div className="card text-black" id='rad'>
                                            <div className="card-body p-md-5">
                                                <div className="row justify-content-center">
                                                    <div className="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">
                                                        <p className="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Sign up</p>
                                                        <Form className="mx-1 mx-md-4" >
                                                            <div className="d-flex flex-row align-items-center mb-4">
                                                                <i className="fas fa-user fa-lg me-3 fa-fw"></i>
                                                                <div className="form-outline flex-fill mb-0">
                                                                    <Field type="text" id="form3Example1c" className="form-control" name='name' placeholder='Your name' />
                                                                    
                                                                      <ErrorMessage name="name" component="span" 
                                                                      className={errors.name && touched.name && 'is-invalid'? 
                                                                        "input-error" : "form-control"} className='error'/>
                                                                    
                                                                    
                                                                </div>
                                                            </div>
                                                            <div className="d-flex flex-row align-items-center mb-4">
                                                                <i className="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                                                <div className="form-outline flex-fill mb-0">
                                                                    <Field type="email" id="form3Example3c" className="form-control" name="email" placeholder="Enter email"
                                                                      />
                                                                    <div>
                                                                      <ErrorMessage name="email" component="span" 
                                                                      className={errors.email && touched.email ? 
                                                                        "input-error" : "form-control"}/>
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                            <div className="d-flex flex-row align-items-center mb-4">
                                                                <i className="fas fa-lock fa-lg me-3 fa-fw"></i>
                                                                <div className="form-outline flex-fill mb-0">
                                                                    <Field type="password" id="form3Example4c" className="form-control" placeholder='Enter password' name="password" autoComplete='false' />
                                                                    <div>
                                                                      <ErrorMessage name="password" component="span" 
                                                                      className={errors.password && touched.password ? 
                                                                        "input-error" : "form-control"}/>
                                                                    </div>
                                                            
                                                                </div>
                                                            </div>
                                                            <div className="d-flex flex-row align-items-center mb-4">
                                                                <i className="fas fa-key fa-lg me-3 fa-fw"></i>
                                                                <div className="form-outline flex-fill mb-0">
                                                                    <Field type="password" id="form3Example4cd" className="form-control" placeholder='Re-enter' name="confirmPassword" autoComplete='false' />
                                                                    <div>
                                                                      <ErrorMessage name="confirmPassword" component="span" 
                                                                      className={errors.confirmPassword&& touched.confirmPassword ? 
                                                                        "input-error" : "form-control"} />
                                                                    </div>
    
                                                                </div>
                                                            </div>
                                                            <div className="form-check d-flex justify-content-center mb-5">
                                                                <Field type='checkbox' name="checkbox" className='chk me-2' />
                                                                <label className="form-check-label" htmlFor="form2Example3">
                                                                    I agree all statements in <a href="#!">Terms of service</a>
                                                                </label>
                                                            </div>
                                                            <div className="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                                                                <button type="submit"
                                                                    className={!(dirty && isValid) ? "disabled btn btn-primary btn-lg" : "btn btn-primary btn-lg"}
                                                                    disabled={!(dirty && isValid)} name='' >Submit</button>
                                                            </div>
                                                        </Form>
                                                    </div>
                                                    <div className="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">
                                                        <img src={img} className="img-fluid" alt="Sample" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                )
            }}
        </Formik>
    )
}

export default Form2;