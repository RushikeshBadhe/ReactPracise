import * as yup from 'yup'
export const userSchema = yup.object().shape({
    name: yup.string().required('name required'),
    email:yup.string().email().required('email required') ,
    password:yup.string().min(8,'min 8 character').required('password required'),
    confirmPassword: yup.string().oneOf([yup.ref("password"),'Pasword should be matched']).required('Re-enter password'),
    checkbox:yup.bool().oneOf([true], 'Field must be checked')
})
