
import { Route,Link, Switch } from 'react-router-dom';
import  Nav  from './components/Nav';
import './App.css';
import AddBlog from './components/AddBlog';
import EditBlog from './components/EditBlog';
import Footer from './components/Footer';
import Header from './components/Header';
import Main from './components/Main';
import { Not } from './components/Not';

function App() {
  return (
    <div>
     <Header></Header>
     
     
     {/* <Link to='/addblog' id='add' className='btn btn-primary'>Add Blog</Link> */}
     
      <Nav></Nav>
   

     <Footer></Footer>
    </div>
  );
}

export default App;
