import img1 from './img/img1.jpg'
import img2 from './img/img2.jpg'
import img3 from './img/img3.jpg'
import Products from './Products';
import { useState } from 'react'
import { useParams } from 'react-router-dom';
function EditBlog(){
    const param = useParams();
    var d = new Date();
    let x = d.toDateString()
    // let dt = '09/16/2021'
    // var date = { currentTime: new Date().toLocaleString() };
    const[blog,SetBlog] = useState({
        pid:"2",
        plogContents:"f",
        postoWner:"g",
        time:x,
        postImg:"",
        likes:0,
        formErrors:{}
    })
    
    
    const handleInput=(e)=>{
         const name = e.target.name;
         const value = e.target.value;
         console.log(name);
        //  SetBlog({blog:value})
        SetBlog({...blog,[name]:value})
    }

      //validation
   let formValidation=()=>{
    const pid = blog.pid;
    let plogContents = blog.plogContents;
    let postoWner = blog.postoWner; 
     let formErrors = {};
     let formIsValid = true;

     if(!pid){
         formIsValid = false;
         formErrors["pidErr"] = "post id require";

     }
     if(!plogContents){
         formIsValid = false;
         formErrors["plogContentsErr"] = "Blog contents require";

     }
     if(!postoWner){
         formIsValid = false;
         formErrors["posownerErr"] = "Post owner require"
     }
     SetBlog({formErrors:formErrors})
     return formIsValid;

 }
    
    const [newPosts,setNewPosts] = useState([
        {pid:101,blogContents:"The idea of a technology school in Georgia was introduced in 1865 during the Reconstruction period. Two former Confederate officers, Major John Fletcher Hanson (an industrialist) and Nathaniel Edwin Harris (a politician and eventually Governor of Georgia), who had become prominent citizens in the town of Macon, Georgia after the Civil War, strongly believed that the South needed to improve its technology to compete with the industrial revolution, which was occurring throughout the Northr"
        ,postOwner:"Carry",time:x,postImg:img3,likes:0},
        {pid:102,blogContents:"The Georgia School of Technology opened in the fall of 1888 with two buildings.[12] One building (now Tech Tower, an administrative headquarters) had classrooms to teach students; The second building featured a shop and had a foundry, forge, boiler room, and engine room. It was designed for students to work and produce goods to sell and fund the school. The two buildings were equal in size to show the importance of teaching both the mind and the hands, though, at the time, there was some disagreement to whether the machine shop should have been used to turn a profit."
        ,postOwner:"Brody",time:x,postImg:img2,likes:6},
        {pid:103,blogContents:"East Campus houses all of the fraternities and sororities as well as most of the undergraduate freshman dormitories. East Campus abuts the Downtown Connector, granting residences quick access to Midtown and its businesses (for example, The Varsity) via a number of bridges over the highway. Georgia Tech football's home, Bobby Dodd Stadium is located on East Campus, as well as Georgia Tech basketball's home, McCamish Pavilion (formerly Alexander Memorial Coliseum)."
        ,postOwner:"Ben",time:x,postImg:img1,likes:9},
        {pid:104,blogContents:""
        ,postOwner:"Ben",time:x,postImg:img1,likes:9},
       
    ]);


    const handleSubmit=(e)=>{
        e.preventDefault();
        console.log(blog);
        // if(formValidation()){
            alert("you have added blog")
        setNewPosts([...newPosts,blog])
    //}

}
    return(
        <>
        <form>
               <p>Post id :{param.pid}</p>
               <p>{param.time}</p>
               <label>Post Owner: </label><input type='text' name="postOwner" value={blog.postOwner} onChange={handleInput}></input>
               <div className="mb-3">
              <label htmlFor="formFile" className="form-label">Default file input example</label>
             <input className="form-control" type="file" id="formFile"/>
             </div>
               <div className="mb-3">
               <label htmlFor="exampleFormControlTextarea1" className="form-label">Blog Contents</label>
             <textarea className="form-control" id="exampleFormControlTextarea1" rows="3" name="blogContents" value={blog.blogContents} onChange={handleInput}></textarea>
             </div>
               <button type="submit">Edit Blog</button>
        </form>
        </>
    )
}

export default EditBlog;