export function Not(){
    return(
        <>
        Not found
        </>
    )
}