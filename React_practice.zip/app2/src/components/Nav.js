import { Route,Link, Switch } from 'react-router-dom';
import AddBlog from './AddBlog';

import EditBlog from './EditBlog';
import Main from './Main';
import { Not } from './Not';
function Nav(){
    return(
        <>
         <Link to='/addblog' id='add' className='btn btn-primary'>Add Blog</Link>
         <Switch>
        <Route exact path='/' component={Main}></Route>
      
        <Route path='/addblog' component={AddBlog}></Route>
      
        <Route path='/editblog/:pid' component={EditBlog}></Route>
        
        
      
        </Switch>
        </>
    )
}

export default Nav;