import './header.css'
import { Route,Link, Switch } from 'react-router-dom';
import AddBlog from './AddBlog';

import EditBlog from './EditBlog';
import Main from './Main';
import { Not } from './Not';
function Header(){
    return(
        <header>
            Cybage Blogspot
        
         
        </header>
    )
}

export default Header;