import {Image} from 'react-bootstrap';
import { useState,useEffect } from 'react';
import PropTypes from 'prop-types';
import { Route,Link,Switch } from 'react-router-dom';
import './main.css';


function Products(props){
    const[Likes,setLikes] = useState(props.info.likes);
    
    let useLikes=()=>{
        setLikes(Likes+1);
    }
    useEffect(()=>{
        console.log('clicked like '+Likes);
    })
    
    console.log("when it run");
    return(
        <div id="cd" className="card w-75">
        <h2> 
            {/* <img className="img-thumbnail" src={info.postImg} alt="Img" />{info.postOwner} */}
            <Image className='roundedCircle' roundedCircle src={props.info.postImg} alt="Img" />{props.info.postOwner}<br/>
            
        </h2>
        <span>{props.info.time}</span>
        {/* <p>{info.time}</p> */}
        <p>{props.info.blogContents}</p>
        {/* <Button className="btn btn-primary">Like {info.likes}</Button> */}
        <button className='btn btn-primary' onClick={useLikes} >Like {Likes}</button><br/>
        <Link to={`/editblog/${props.info.pid}`} className='btn btn-primary'>Edit</Link><br/>
        
        <button  className="del" onClick={()=>{
            props.delete(props.id)
        }} >Delete </button>
    </div>
    )
}

Products.propTypes={
    blogContents:PropTypes.string.isRequired,
    postOwner:PropTypes.string.isRequired
    
    // postImg:propTypes.
    

}

export default Products;