import './footer.css'
import React from 'react'
class Footer extends React.Component{
    render(){
    return(  
        <footer>
            www.cybageblogspot.com
        </footer>
    )
}
}

export default Footer;