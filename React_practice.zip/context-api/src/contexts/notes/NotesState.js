import React, { useState } from 'react'
import NoteContext from './NotesContext'

function NotesState(props) {
  
    const data = {
       "name":"Rushi",
       "bYear":"1998"
    }
    const [info,setInfo] = useState(data)
    const changeName=()=>{
        setTimeout(() => {
            setInfo({
             "name":"Pushkar",
             "bYear":"1998"   
            })
        },3000);
    }
  return (
    
            <NoteContext.Provider value={{info,changeName}}>
                {props.children}
            </NoteContext.Provider>
      
  )
}

export default NotesState