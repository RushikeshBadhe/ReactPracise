import React,{useContext,useEffect} from 'react'
import NoteContext from '../contexts/notes/NotesContext'
function CompC() {
  const a  = useContext(NoteContext);
  useEffect(() => {
    a.changeName()
  }, [a])
  
  return (
    <div>

      CompC
      <div>
        Getting data from context api in comp c
        <p>Name: {a.info.name}</p>
        <p>bYear:{a.info.bYear}</p>
      </div>
      
    </div>
  )
}

export default CompC