import React from 'react'
import CompB from './CompB'

function CompA() {
  return (
    <div>
      CompA
      <CompB/>
      </div>
  )
}

export default CompA