import React from 'react'
import CompC from './CompC'
function CompB() {
  return (
    <div>
      CompB
      <CompC/>
      </div>
  )
}

export default CompB