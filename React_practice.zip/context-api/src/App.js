
import './App.css';
import CompA from './components/CompA';
import NotesState from './contexts/notes/NotesState';

function App() {
  return (
    <div className='App'>
    <NotesState>
   
       <CompA/>
     </NotesState>
    </div>
  );
}

export default App;
