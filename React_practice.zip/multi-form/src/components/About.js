import React from 'react'
import {useParams} from 'react-router-dom'
function About() {
    let {uname} = useParams();
    return (
        <div>
            <h1>THIS IS ABOUT US {uname} </h1>
        </div>
    )
}

export default About
