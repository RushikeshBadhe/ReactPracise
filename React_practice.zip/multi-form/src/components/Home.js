import React from 'react'

function Home() {
    return (
        <div>
            <h1>THIS IS HOME PAGE</h1>
        </div>
    )
}

export default Home
