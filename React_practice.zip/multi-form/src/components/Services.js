import React from 'react'
import {useNavigate} from 'react-router-dom'
function Services() {
    let navi = useNavigate();
    return (
        <div>
            <h1>THIS IS SERVICE PAGE</h1>
            <button onClick={()=>navi("/about")} >Go to About</button>
        </div>
    )
}

export default Services
