
import './App.css';
import Contact from './components/Contact';
import Navbar from './components/Navbar';
import { Routes,Route} from "react-router-dom";
import {Switch} from "react-dom"
import Home from './components/Home';
import Services from './components/Services';
import About from './components/About';
function App() {
  return (
    <div>
    
   <Navbar/>
    <Routes>
      <Route path="/contact" element={<Contact/>}></Route>
      <Route path="/" element={<Home/>}></Route>
      <Route path="/services" element={<Services/>}></Route>
      <Route path="/about/:uname" element={<About/>}></Route>
      <Route path="*" element={<Home/>}></Route>
    </Routes>
    
    </div>
  );
}

export default App;
