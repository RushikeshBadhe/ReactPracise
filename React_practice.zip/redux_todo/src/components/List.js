import React, { useState } from 'react'

function List() {
  const [todo,setTodo] = useState('');
  let onchange=(e)=>{
    setTodo(e.target.value)
  }
  let arr=['Hello','Hey'];
  let add=()=>{
    arr.push(todo)
    console.log(arr);
  }
  return (
    <div >
        <input className='ip' placeholder='Type todo' onChange={onchange}/>
        <button onClick={add}>Add</button>
        <div>
          {arr}
        </div>
       
    </div>
  )
}

export default List;
