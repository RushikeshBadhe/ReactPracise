export function useBudget(){}

export const BudgetsProvider = ({childern})=>{
    return childern
}