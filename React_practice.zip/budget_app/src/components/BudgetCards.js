import React from 'react'
import { Button, Card, ProgressBar, Stack } from 'react-bootstrap'
import {currencyFormatter} from '../utils'
function BudgetCards(props) {
   
    const className = []

    if(props.amount>props.max){
        className.push("bg-danger","bg-opacity-10")
    }else if(props.gray) {
        className.push("bg-light")
    }

    function getProgressBarVarient(amount,max){
        const ratio = amount/max;
        if(ratio<0.5) return "primary"
        if(ratio<0.75) return "warning"
        return "danger"
    }
    return (
        <div>
            <Card>
                <Card.Body>
                    <Card.Title>
                        <div>{props.name}</div>
                        <div>{currencyFormatter.format(props.amount)}/
                        {currencyFormatter.format(props.max)}</div>
                        
                    </Card.Title>
                    <ProgressBar className='rounded-pill' variant={getProgressBarVarient(props.amount,props.max)}
                    min={0}
                    gray
                    max={props.max}
                    now={props.amount}
                    />
                    <Stack direction='horozontal' gap="2" className='mt-4'>
                        <Button variant='outline-primary' className='ms-auto' >Add Expense</Button>
                        <Button variant='outline-secondary' className='ms-auto'>View Expense</Button>
                    </Stack>
                </Card.Body>
            </Card>
        </div>
    )
}

export default BudgetCards
