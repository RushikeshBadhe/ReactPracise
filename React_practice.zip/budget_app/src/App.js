
 import { Button, Container, Stack } from 'react-bootstrap';
 import BudgetCards from './components/BudgetCards';
function App() {
  return (
    <div >
      <Container className='my-4' >
       <Stack direction='horizontal' gap='2' className='mb-4'>
        <h1 className='me-auto'>Budget</h1>
        <Button varient='' >Add Budget</Button>
        <Button className='btn btn-info' >Add Expense</Button>
       </Stack>
       <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px.1fr))',
       gap:"1rem" ,alignItems:"flex-start"}}>
         <BudgetCards name="Entertainmet" amount={200} max={10000} ></BudgetCards>
       </div>
      </Container>
    </div>
  );
}
export default App;


