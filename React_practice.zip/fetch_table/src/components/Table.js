import React, { useState, useEffect } from 'react'
import axios from 'axios';
import '../App.css'
function Table() {
    const [data, setData] = useState([]);
    useEffect(() => {
        axios.get('https://reqres.in/api/users?page=2').then((res) => {
            setData(res.data.data)
        })
    }, [])
    console.log(data);
    return (
        <div>
            <h2>Table</h2>
            <table>
                <thead>
                <tr>
                    <th>Id</th>
                    <th>F-Name</th>
                    <th>L-Name</th>
                    <th>Email</th>
                </tr>
                </thead>
               <tbody>
                   {
                       data.map((info,index)=>{
                           return(
                            <tr key={index}>
                            <td>{info.id}</td>
                            <td>{info.first_name}</td>
                            <td>{info.last_name}</td>
                            <td>{info.email}</td>
                        </tr>
                           )
                       })
                   }
               </tbody>
            </table>
        </div>
    )
}

export default Table